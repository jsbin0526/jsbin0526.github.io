import string
import matplotlib.pyplot as plt
import numpy as np
import pygame as pg

white = (255, 255, 255)
black = (0, 0, 0)
red = (192, 0, 0)
cyan = (16, 138, 139)
gray = (121, 121, 121)


def erase_useless_string(text):
    i = 0
    result = ""
    while True:
        if text[i] == "=":
            text = text[i + 1:]
            break
        else:
            i += 1
    for j in text:
        if j != (" " or "\n"): result += j
    if result in string.digits:
        return result
    else:
        return result[0].upper() + result[1:].lower()


asset_url = 'Settings.txt'
try:
    f = open(asset_url, "r")
    line = f.readlines()
except:
    line = [1600, 900, False, 10000, -0.5]
    width = int(erase_useless_string(line[0]))
    height = int(erase_useless_string(line[1]))
    fullscreen_toggle = True if erase_useless_string(line[2]) == "True" else False

class Big:
    def __init__(self):
        self.size = height // 9
        self.position = [width // 4 * 3, height // 4 * 3]
        self.color = cyan
        self.mass = int(erase_useless_string(line[3]))
        self.velocity = float(erase_useless_string(line[4]))
        self.count = 0

    def move(self):
        self.position[0] += self.velocity

    def draw(self, screen):
        draw_cube(screen, self.color, self.size, self.position[0], self.position[1])


class Small:
    def __init__(self):
        self.size = height // 18
        self.position = [width // 4, height // 4 * 3 + self.size]
        self.color = red
        self.mass = 1
        self.velocity = 0

    def move(self):
        self.position[0] += self.velocity

    def draw(self, screen):
        draw_cube(screen, self.color, self.size, self.position[0], self.position[1])


def draw_cube(screen, color, size, x, y):
    cube = pg.Rect((x, y), (size, size))
    pg.draw.rect(screen, color, cube)


def write_collide(screen, color, font, count):
    text = font.render(str(count), 1, black)
    screen.blit(text, (0, 0))


def draw_background(screen, color, size):
    wall = pg.Rect((0, 0), (size, height))
    floor = pg.Rect((0, height * 31 // 36), (width, height * 31 // 36))
    pg.draw.rect(screen, color, wall)
    pg.draw.rect(screen, color, floor)


def main():
    pg.init()
    pg.font.init()
    font = pg.font.SysFont("Malgun Gothic", 100)
    pg.display.set_caption('Physics')
    screen = pg.display.set_mode((width, height), fullscreen_toggle)
    wall_x = width // 8
    big = Big()
    small = Small()
    x_array = [big.mass ** (1 / 2) * big.velocity]
    y_array = [0]
    count = 0
    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                exit()
        screen.fill(white)
        draw_background(screen, gray, wall_x)
        big.draw(screen)
        big.move()
        small.draw(screen)
        small.move()
        write_collide(screen, black, font, count)
        pg.display.update()
        if small.position[0] <= wall_x:
            small.velocity *= -1
            count += 1
        if big.position[0] <= small.position[0] + small.size:
            temp_big = (big.velocity * (big.mass - small.mass) + 2 * small.mass * small.velocity) / \
                       (big.mass + small.mass)
            small.velocity = (small.velocity * (small.mass - big.mass) + 2 * big.mass * big.velocity) / (
                    big.mass + small.mass)
            big.velocity = temp_big
            x_array.append(big.mass ** (1 / 2) * big.velocity)
            y_array.append(small.velocity)
            count += 1
        if 0 < small.velocity < big.velocity:
            x = np.array(x_array)
            y1 = np.array(y_array)
            y2 = np.array(list(map(lambda a: -a, y_array)))
            print(x)
            print(y1)
            print(y2)
            plt.plot(x, y1)
            plt.plot(x, y2)
            plt.xlabel("Big's energy")
            plt.ylabel("Small's energy")
            plt.title('Physics')
            plt.legend(['Collide with cube', 'Collide with wall'])
            plt.show()
            pg.quit()
            exit()


if __name__ == '__main__':
    main()
